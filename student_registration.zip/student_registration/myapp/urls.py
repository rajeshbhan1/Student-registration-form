from django.contrib import admin
from django.urls import path
from myapp import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.home),
    path('load_form', views.load_form),
    path('add', views.add),
    path('show', views.show),
    path('search', views.search),
    path('delete/<int:id>', views.delete),
    path('login', views.about),
]
