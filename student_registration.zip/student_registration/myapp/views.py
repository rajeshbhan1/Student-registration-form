
# Create your views here.
from django.shortcuts import render, redirect
from .models import Student
from .forms import StudentForm
# Create your views here.
def home(request):
    return render(request, "welcome.html")
def about(request):
    return render(request, "login.html")

def load_form(request):
    form = StudentForm
    return render(request, "index.html", {'form': form})
def add(request):
    form = StudentForm(request.POST)
    form.save()
    return redirect('/show')
def show(request):
    student = Student.objects.all
    return render(request, 'show.html', {'student': student})
def search(request):
    given_name = request.POST['name']
    student = Student.objects.filter(sname=given_name)
    return render(request, 'show.html', {'student': student})
def delete(request,id):
    student = Student.objects.get(id=id)
    student.delete()
    return redirect('/show')